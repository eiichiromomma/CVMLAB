//CLR�t�H�[���A�v����OpenCV���g����(���Ȃ��G�c
// 2008/2/13 Eiichiro Momma
#pragma once
#include "OpenCVUtils.h"

namespace CLR_OpenCV_Template {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
  using namespace OpenCVUtils;

	/// <summary>
	/// Form1 �̊T�v
	///
	/// �x��: ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ��A
	///          ���������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{

	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: �����ɃR���X�g���N�^ �R�[�h��ǉ����܂�
			//
		}

	protected:
		/// <summary>
		/// �g�p���̃��\�[�X�����ׂăN���[���A�b�v���܂��B
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
  private: System::Windows::Forms::Panel^  panel1;
  protected: 
  private: System::Windows::Forms::PictureBox^  pictureBox1;
  private: System::Windows::Forms::MenuStrip^  menuStrip1;
  private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
  private: System::Windows::Forms::ToolStripMenuItem^  openToolStripMenuItem;
  private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator1;
  private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;
  private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;
  private: System::Windows::Forms::ToolStripMenuItem^  openCVToolStripMenuItem;
  private: System::Windows::Forms::ToolStripMenuItem^  cvFlipToolStripMenuItem;
  private: System::Windows::Forms::ToolStripMenuItem^  cvInverseToolStripMenuItem;

	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
      this->panel1 = (gcnew System::Windows::Forms::Panel());
      this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
      this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
      this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->openToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
      this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->openCVToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->cvFlipToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->cvInverseToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
      this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
      this->panel1->SuspendLayout();
      (cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
      this->menuStrip1->SuspendLayout();
      this->SuspendLayout();
      // 
      // panel1
      // 
      this->panel1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
        | System::Windows::Forms::AnchorStyles::Left) 
        | System::Windows::Forms::AnchorStyles::Right));
      this->panel1->AutoScroll = true;
      this->panel1->Controls->Add(this->pictureBox1);
      this->panel1->Location = System::Drawing::Point(13, 27);
      this->panel1->Name = L"panel1";
      this->panel1->Size = System::Drawing::Size(666, 408);
      this->panel1->TabIndex = 0;
      // 
      // pictureBox1
      // 
      this->pictureBox1->Location = System::Drawing::Point(3, 3);
      this->pictureBox1->Name = L"pictureBox1";
      this->pictureBox1->Size = System::Drawing::Size(244, 205);
      this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
      this->pictureBox1->TabIndex = 0;
      this->pictureBox1->TabStop = false;
      this->pictureBox1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form1::pictureBox1_Paint);
      // 
      // menuStrip1
      // 
      this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->fileToolStripMenuItem, 
        this->openCVToolStripMenuItem});
      this->menuStrip1->Location = System::Drawing::Point(0, 0);
      this->menuStrip1->Name = L"menuStrip1";
      this->menuStrip1->Size = System::Drawing::Size(691, 24);
      this->menuStrip1->TabIndex = 1;
      this->menuStrip1->Text = L"menuStrip1";
      // 
      // fileToolStripMenuItem
      // 
      this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->openToolStripMenuItem, 
        this->toolStripSeparator1, this->exitToolStripMenuItem});
      this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
      this->fileToolStripMenuItem->Size = System::Drawing::Size(36, 20);
      this->fileToolStripMenuItem->Text = L"File";
      // 
      // openToolStripMenuItem
      // 
      this->openToolStripMenuItem->Name = L"openToolStripMenuItem";
      this->openToolStripMenuItem->Size = System::Drawing::Size(96, 22);
      this->openToolStripMenuItem->Text = L"Open";
      this->openToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::openToolStripMenuItem_Click);
      // 
      // toolStripSeparator1
      // 
      this->toolStripSeparator1->Name = L"toolStripSeparator1";
      this->toolStripSeparator1->Size = System::Drawing::Size(93, 6);
      // 
      // exitToolStripMenuItem
      // 
      this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
      this->exitToolStripMenuItem->Size = System::Drawing::Size(96, 22);
      this->exitToolStripMenuItem->Text = L"Exit";
      this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem_Click);
      // 
      // openCVToolStripMenuItem
      // 
      this->openCVToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->cvFlipToolStripMenuItem, 
        this->cvInverseToolStripMenuItem});
      this->openCVToolStripMenuItem->Name = L"openCVToolStripMenuItem";
      this->openCVToolStripMenuItem->Size = System::Drawing::Size(59, 20);
      this->openCVToolStripMenuItem->Text = L"OpenCV";
      // 
      // cvFlipToolStripMenuItem
      // 
      this->cvFlipToolStripMenuItem->Enabled = false;
      this->cvFlipToolStripMenuItem->Name = L"cvFlipToolStripMenuItem";
      this->cvFlipToolStripMenuItem->Size = System::Drawing::Size(106, 22);
      this->cvFlipToolStripMenuItem->Text = L"cvFlip";
      this->cvFlipToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::cvFlipToolStripMenuItem_Click);
      // 
      // cvInverseToolStripMenuItem
      // 
      this->cvInverseToolStripMenuItem->Enabled = false;
      this->cvInverseToolStripMenuItem->Name = L"cvInverseToolStripMenuItem";
      this->cvInverseToolStripMenuItem->Size = System::Drawing::Size(106, 22);
      this->cvInverseToolStripMenuItem->Text = L"cvXorS";
      this->cvInverseToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::cvInverseToolStripMenuItem_Click);
      // 
      // openFileDialog1
      // 
      this->openFileDialog1->FileName = L"openFileDialog1";
      this->openFileDialog1->Filter = L"Images{*.png;*.jpg;*.bmp}|*.png; *.jpg; *.bmp";
      this->openFileDialog1->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &Form1::openFileDialog1_FileOk);
      // 
      // Form1
      // 
      this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
      this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
      this->ClientSize = System::Drawing::Size(691, 447);
      this->Controls->Add(this->panel1);
      this->Controls->Add(this->menuStrip1);
      this->MainMenuStrip = this->menuStrip1;
      this->Name = L"Form1";
      this->Text = L"Form1";
      this->panel1->ResumeLayout(false);
      this->panel1->PerformLayout();
      (cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
      this->menuStrip1->ResumeLayout(false);
      this->menuStrip1->PerformLayout();
      this->ResumeLayout(false);
      this->PerformLayout();

    }
#pragma endregion

  private: //Momma �ǉ���
    ref class OpenCVUtils ocu;

  private: System::Void openToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
           //���j���[��Open
             this->openFileDialog1->ShowDialog();
           }
private: System::Void openFileDialog1_FileOk(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
           //���j���[��Open��OK�̏���
           this->Activate();
           char fname[1024];
           if (ocu.iplImg != NULL){
             IplImage* iptr = ocu.iplImg;
             cvReleaseImage(&iptr);
           }
           ocu.StringToCharPointer(this->openFileDialog1->FileName,fname,1024);
           ocu.iplImg = cvLoadImage(fname,1);
           if (ocu.iplImg != NULL){
             ocu.RefreshBitmap();
             this->pictureBox1->Refresh();
             for each (System::Windows::Forms::ToolStripMenuItem^ m in this->openCVToolStripMenuItem->DropDownItems){
               m->Enabled = true;
             }
           }else{
             for each (System::Windows::Forms::ToolStripMenuItem^ m in this->openCVToolStripMenuItem->DropDownItems){
               m->Enabled = false;
             }
           }
         }

private: System::Void exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
           this->Close();
         }
private: void myFlip(void){
           //OpenCV�ł̏����̗�
           //�u�����������ȏꍇ��A���h�D���s�Ȃ������ꍇ��OpenCVUtils��IplImage*(�������͂���Array)�̃o�b�t�@��u��
           cvFlip(ocu.iplImg, ocu.iplImg,1);
           ocu.RefreshBitmap();
         }
private: void myXor(void){
           //OpenCV�ł̏����̗Ⴛ��2
           cvXorS(ocu.iplImg, cvScalar(255,255,255), ocu.iplImg);
           ocu.RefreshBitmap();
         }
private: System::Void cvFlipToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
           if (ocu.bmpImg != nullptr){
             myFlip();
             this->pictureBox1->Refresh();
           }
         }
private: System::Void cvInverseToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
           if (ocu.bmpImg != nullptr){
             myXor();
             this->pictureBox1->Refresh();
           }
         }

private: System::Void pictureBox1_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {
           if (ocu.bmpImg != nullptr){
             this->pictureBox1->Width= ocu.bmpImg->Width;
             this->pictureBox1->Height = ocu.bmpImg->Height;
             e->Graphics->DrawImage(ocu.bmpImg,0,0);
           }
         }
};
}

