//CLR�t�H�[���A�v����OpenCV���g����(���Ȃ��G�c
// 2008/2/13 Eiichiro Momma
#pragma once

#include <cv.h>
#include <highgui.h>
#include < vcclr.h >

namespace OpenCVUtils {
  using namespace System;
  using namespace System::ComponentModel;
  using namespace System::Collections;
  using namespace System::Windows::Forms;
  using namespace System::Data;
  using namespace System::Drawing;

  //http://www.trex.co.nr/ ����q�؂̔q��(GPL)

  /*!
   * \brief
   * The Code in this file was copy from OpenCVDotNet Project
   * http://code.google.com/p/opencvdotnet/
   */
  ref class Utils
  {
  private:

    static void FillBitmapInfo( BITMAPINFO* bmi, int width, int height, int bpp, int origin )
    {
      assert( bmi && width >= 0 && height >= 0 && (bpp == 8 || bpp == 24 || bpp == 32));

      BITMAPINFOHEADER* bmih = &(bmi->bmiHeader);

      memset( bmih, 0, sizeof(*bmih));
      bmih->biSize = sizeof(BITMAPINFOHEADER);
      bmih->biWidth = width;
      bmih->biHeight = origin ? abs(height) : -abs(height);
      bmih->biPlanes = 1;
      bmih->biBitCount = (unsigned short)bpp;
      bmih->biCompression = BI_RGB;

      if( bpp == 8 )
      {
        RGBQUAD* palette = bmi->bmiColors;
        int i;
        for( i = 0; i < 256; i++ )
        {
          palette[i].rgbBlue = palette[i].rgbGreen = palette[i].rgbRed = (BYTE)i;
          palette[i].rgbReserved = 0;
        }
      }
    }

  public:
    static Bitmap^ IplImageToBitmap(IplImage *sourceImage)
    {
      
      int height = 0;
      int width = 0;
      int channels = 0;
      void* dst_ptr = 0;
      const int channels0 = 3;
      int origin = 0;
      CvMat stub, dst, *image;
      bool changed_size = false; // philipg

      HDC hdc = CreateCompatibleDC(0);
      CvArr* arr = (CvArr*)sourceImage;

      if (CV_IS_IMAGE_HDR(arr)) origin = ((IplImage*)arr)->origin;

      image = cvGetMat(arr, &stub);

      uchar buffer[sizeof(BITMAPINFO) + 255*sizeof(RGBQUAD)];
      BITMAPINFO* binfo = (BITMAPINFO*)buffer;

      width = image->width;
      height = image->height;
      channels = channels0;

      FillBitmapInfo(binfo, width, height, channels*8, 1);

      HBITMAP hBitmap = CreateDIBSection(hdc, binfo, DIB_RGB_COLORS, &dst_ptr, 0, 0);
      if (hBitmap == NULL)
        return nullptr;

      cvInitMatHeader(&dst, height, width, CV_8UC3, dst_ptr, (width * channels + 3) & -4);
      cvConvertImage(image, &dst, origin == 0 ? CV_CVTIMG_FLIP : 0);

      System::Drawing::Bitmap^ bmpImage = System::Drawing::Image::FromHbitmap(IntPtr(hBitmap));

      DeleteObject(hBitmap);
      DeleteDC(hdc);

      return bmpImage;
    }


    static void StringToCharPointer(String^ string, char* output, int size)
    {
      pin_ptr<const __wchar_t> p = PtrToStringChars(string);
      wcstombs_s(NULL, output, size, p, size);
    }
  };
  //http://www.trex.co.nr/ ����q�؂̔q�؏I��

  ref class OpenCVUtils:Utils
  {
  public:
    OpenCVUtils(){
      iplImg_ = NULL;
    }

    property IplImage* iplImg{ //IplImage�͍Œ���̊Ǘ�
      IplImage* get(){
        return iplImg_;
      }
      Void set(IplImage* val){
        iplImg_ = val;
      }
    }
  
    property Bitmap^ bmpImg
    {
      Bitmap^ get(){
        return bmpImg_;
      }
    }

  public: Void RefreshBitmap(){
      delete bmpImg_;
      bmpImg_ = IplImageToBitmap(iplImg_);
    }

  private:
    Bitmap^ bmpImg_;
    IplImage* iplImg_;

  };
}