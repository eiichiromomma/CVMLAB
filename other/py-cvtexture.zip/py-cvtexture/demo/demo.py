#!/usr/bin/python
#2008/9/16 Eiichiro Momma
from opencv import cv
from opencv import highgui
from cvtexture import cvtexture

if False:
    src = cv.cvCreateImage(cv.cvSize(4,4),cv.IPL_DEPTH_8U,1)
    cv.cvSetReal2D(src, 0, 0, 0)
    cv.cvSetReal2D(src, 0, 1, 0)
    cv.cvSetReal2D(src, 0, 2, 1)
    cv.cvSetReal2D(src, 0, 3, 1)
    cv.cvSetReal2D(src, 1, 0, 0)
    cv.cvSetReal2D(src, 1, 1, 0)
    cv.cvSetReal2D(src, 1, 2, 1)
    cv.cvSetReal2D(src, 1, 3, 1)
    cv.cvSetReal2D(src, 2, 0, 0)
    cv.cvSetReal2D(src, 2, 1, 2)
    cv.cvSetReal2D(src, 2, 2, 2)
    cv.cvSetReal2D(src, 2, 3, 2)
    cv.cvSetReal2D(src, 3, 0, 2)
    cv.cvSetReal2D(src, 3, 1, 2)
    cv.cvSetReal2D(src, 3, 2, 3)
    cv.cvSetReal2D(src, 3, 3, 3)

else:
    src = highgui.cvLoadImage("test.png",0)

glcm = cvtexture.cvCreateGLCM(src, 1, None, 4, cvtexture.CV_GLCM_OPTIMIZATION_LUT)
cvtexture.cvCreateGLCMDescriptors(glcm, cvtexture.CV_GLCMDESC_OPTIMIZATION_ALLOWDOUBLENEST)
#CV_GLCMDESC_ENTROPY                         0
#CV_GLCMDESC_ENERGY                          1
#CV_GLCMDESC_HOMOGENITY                      2
#CV_GLCMDESC_CONTRAST                        3
#CV_GLCMDESC_CLUSTERTENDENCY                 4
#CV_GLCMDESC_CLUSTERSHADE                    5
#CV_GLCMDESC_CORRELATION                     6
#CV_GLCMDESC_CORRELATIONINFO1                7
#CV_GLCMDESC_CORRELATIONINFO2                8
#CV_GLCMDESC_MAXIMUMPROBABILITY              9
for step in range(4):
    for i in range(10):
        print str(cvtexture.cvGetGLCMDescriptor(glcm, step, i))
    print "\n"

d0org = cv.cvCreateImage(cv.cvSize(256,256),cv.IPL_DEPTH_32F,1)
tmp=cvtexture.cvCreateGLCMImage(glcm,0)
cv.cvResize(tmp,d0org,cv.CV_INTER_NN)
d0 = cv.cvCreateImage(cv.cvGetSize(d0org),cv.IPL_DEPTH_8U,1)
cv.cvConvertScaleAbs(d0org,d0,255,0)
cv.cvNormalize(d0,d0,0,255,cv.CV_MINMAX)
highgui.cvSaveImage("d0.png",d0)
highgui.cvNamedWindow("D0",1)
highgui.cvShowImage("D0",d0)

d2org = cv.cvCreateImage(cv.cvSize(256,256),cv.IPL_DEPTH_32F,1)
tmp=cvtexture.cvCreateGLCMImage(glcm,2)
cv.cvResize(tmp,d2org,cv.CV_INTER_NN)
d2 = cv.cvCreateImage(cv.cvGetSize(d2org),cv.IPL_DEPTH_8U,1)
cv.cvConvertScaleAbs(d2org,d2,255,0)
cv.cvNormalize(d2,d2,0,255,cv.CV_MINMAX)
highgui.cvSaveImage("d2.png",d2)
highgui.cvNamedWindow("D2",1)
highgui.cvShowImage("D2",d2)

d3org = cv.cvCreateImage(cv.cvSize(256,256),cv.IPL_DEPTH_32F,1)
tmp=cvtexture.cvCreateGLCMImage(glcm,3)
cv.cvResize(tmp,d3org,cv.CV_INTER_NN)
d3 = cv.cvCreateImage(cv.cvGetSize(d3org),cv.IPL_DEPTH_8U,1)
cv.cvConvertScaleAbs(d3org,d3,255,0)
cv.cvNormalize(d3,d3,0,255,cv.CV_MINMAX)
highgui.cvSaveImage("d3.png",d3)
highgui.cvNamedWindow("D3",1)
highgui.cvShowImage("D3",d3)

d1org = cv.cvCreateImage(cv.cvSize(256,256),cv.IPL_DEPTH_32F,1)
tmp=cvtexture.cvCreateGLCMImage(glcm,1)
cv.cvResize(tmp,d1org,cv.CV_INTER_NN)
d1 = cv.cvCreateImage(cv.cvGetSize(d1org),cv.IPL_DEPTH_8U,1)
cv.cvConvertScaleAbs(d1org,d1,255,0)
cv.cvNormalize(d1,d1,0,255,cv.CV_MINMAX)
highgui.cvSaveImage("d1.png",d1)
highgui.cvNamedWindow("D1",1)
highgui.cvShowImage("D1",d1)

cvtexture.cvReleaseGLCM(glcm,cvtexture.CV_GLCM_ALL)

highgui.cvWaitKey(0)
highgui.cvDestroyAllWindows()

