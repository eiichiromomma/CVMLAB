#!/bin/bash
swig -c++ -python -o cvtexture_wrap.cpp  cvtexture.i
g++ -c cvtexture.cpp cvtexture_wrap.cpp -I/usr/include/opencv -I/usr/include/python2.5 `pkg-config --cflags opencv`
ld -shared -nostdlib cvtexture.o cvtexture_wrap.o  -o _cvtexture.so -L/usr/lib `pkg-config --libs opencv`
mkdir -p cvtexture
touch cvtexture/__init__.py
mv _cvtexture.so cvtexture/
mv cvtexture.py cvtexture/
rm -r ~/pythonlib/cvtexture
mv cvtexture ~/pythonlib
