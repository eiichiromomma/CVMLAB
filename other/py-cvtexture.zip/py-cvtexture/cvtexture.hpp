//2008/9/16 Modified by Eiichiro Momma
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <cv.h>
#include <cxcore.h>
#include <cxtypes.h>
#include <cxmisc.h>
#include <highgui.h>

#ifdef __cplusplus
extern "C" {
#endif

#define CV_GLCM_OPTIMIZATION_NONE                   -2
#define CV_GLCM_OPTIMIZATION_LUT                    -1
#define CV_GLCM_OPTIMIZATION_HISTOGRAM              0

#define CV_GLCMDESC_OPTIMIZATION_ALLOWDOUBLENEST    10
#define CV_GLCMDESC_OPTIMIZATION_ALLOWTRIPLENEST    11
#define CV_GLCMDESC_OPTIMIZATION_HISTOGRAM          4

#define CV_GLCMDESC_ENTROPY                         0
#define CV_GLCMDESC_ENERGY                          1
#define CV_GLCMDESC_HOMOGENITY                      2
#define CV_GLCMDESC_CONTRAST                        3
#define CV_GLCMDESC_CLUSTERTENDENCY                 4
#define CV_GLCMDESC_CLUSTERSHADE                    5
#define CV_GLCMDESC_CORRELATION                     6
#define CV_GLCMDESC_CORRELATIONINFO1                7
#define CV_GLCMDESC_CORRELATIONINFO2                8
#define CV_GLCMDESC_MAXIMUMPROBABILITY              9

#define CV_GLCM_ALL                                 0
#define CV_GLCM_GLCM                                1
#define CV_GLCM_DESC                                2

typedef struct CvGLCM CvGLCM;

CvGLCM* cvCreateGLCM(const IplImage *srcImage,
                                int stepMagnitude,
                                const int* stepDirections =0,
                                int numStepDirections =0,
                                int optimizationType =CV_GLCM_OPTIMIZATION_NONE);

void cvReleaseGLCM( CvGLCM* GLCM, int flag =CV_GLCM_ALL);

void cvCreateGLCMDescriptors( CvGLCM* destGLCM,
                                        int descriptorOptimizationType
                                        =CV_GLCMDESC_OPTIMIZATION_ALLOWDOUBLENEST);

double cvGetGLCMDescriptor( CvGLCM* GLCM, int step, int descriptor );

void cvGetGLCMDescriptorStatistics( CvGLCM* GLCM, int descriptor,
                                              double* average, double* standardDeviation );

CvMat* cvCreateGLCMImage( CvGLCM* GLCM, int step );

#ifdef __cplusplus
}
#endif
