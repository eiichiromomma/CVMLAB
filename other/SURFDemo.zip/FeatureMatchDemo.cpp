/********************************************************************************************
 FeatureMatchDemo.cpp : Display feature matching between a camera image and reference images
 OpenCV Demo program for RSJ2011
 E.Momma and T.Minagawa

 This program
 1. loads image files listed in a text file
 2. extracts features from these images and creates database
 3. captures an image from camera and extracts its feature points
 4. seraches matching feature points in database
 5. draws matching points
*********************************************************************************************/

#include <iostream>
#include <string>
#include <fstream>
#include <time.h>

#include "opencv2/opencv.hpp"

using namespace std;
using namespace cv;

// read image files listed in a text file
// registlist: text file name
// imglist: loaded images are put into this
// sum_size: summation of loaded image size
// max_size: maximum rows and cols of loaded image
void read_regist_img(string registlist, vector<Mat>& imglist, Size& sum_size, Size& max_size)
{
	imglist.clear();

	string buf;
	ifstream ifs(registlist.c_str());
	sum_size = Size(0,0);
	max_size = Size(0,0);
	if(ifs!=NULL){
		bool exitflag2 = false;
		int count = 0;
		int id = 0;
		string::size_type	index;
		string imgfile;
		string id_str;
		while(ifs && getline(ifs, buf)){
			index = buf.find(",");
			id++;
			imgfile = buf;

			cout << id << ":" << imgfile << endl;
			Mat studyimg = imread(imgfile);	// load image
			imglist.push_back(studyimg);
			sum_size.width += studyimg.cols;
			sum_size.height+= studyimg.rows;
			if(studyimg.cols > max_size.width){
				max_size.width = studyimg.cols;
			}
			if(studyimg.rows > max_size.height){
				max_size.height = studyimg.rows;
			}
		}
		ifs.close();
	}
}

// draw matching points
void drawMatchingPoints(Mat& src_img, const Point2f& src_pt, const Point2f& dest_pt, const Point& offset, float scale, Scalar color)
{
	Point2f dpt;
	dpt.x = dest_pt.x * scale + offset.x;
	dpt.y = dest_pt.y * scale + offset.y;
	cv::line(src_img, src_pt, dpt, color);
}



int main( )
{
	string image_file_list = "regist.csv";	// regist image path list
	string detectorType = "SURF";	// feature detector name
	string descriptorType = "SURF";	// feature descriptor name
	string matcherType = "FlannBased";	// feature matcher name

	// color of draw lines
	Scalar	color[] = {
		Scalar(0,255,255), 
		Scalar(0,0,255),
		Scalar(255,0,0),
		Scalar(255,0,0),
		Scalar(255,255,0),
		Scalar(255,0,255),
		Scalar(255,255,255), 
		Scalar(0,0,0)
	};


	vector<Mat> imglist;
	Size sum_size, max_size;
	read_regist_img(image_file_list, imglist, sum_size, max_size);	// load images to regist into database

	Ptr<FeatureDetector>	feature_detector = FeatureDetector::create(detectorType);	// create feature detector
	Ptr<DescriptorExtractor> descriptor_extractor = DescriptorExtractor::create(descriptorType);	// create descriptor extractor
	Ptr<DescriptorMatcher>	descriptor_matcher = DescriptorMatcher::create(matcherType);	// create descriptor matcher

	// Extract feature points from images
	vector<vector<KeyPoint> > kpt_db;	// list of extracted key points from registered images
	vector<Mat> descriptor_db;	// list of extracted descriptors from registered images

	feature_detector->detect(imglist, kpt_db);	// detect key points from imagelist and put them into kpt_db
	descriptor_extractor->compute(imglist, kpt_db, descriptor_db);	// extract feature descriptors from registred images at key point

	descriptor_matcher->add(descriptor_db);	// add extracted feature descriptors into matcher
	descriptor_matcher->train();	// create index for extracted features

	// Class of camera capture
	cv::VideoCapture	capture( 0 );

	if( !capture.isOpened() ) {
		std::cout << "Failed to Open Camera" << std::endl;
		return -1;
	}

	Mat	frame;
	capture >> frame;		// capture an image from camera

	/** create result image to display **/ 
	Size framesize = frame.size();	
	float scale = (float)framesize.height / sum_size.height;	// ratio of display image size and registered image size
	Size imgsize = Size(framesize.width + scale * max_size.width + 1, framesize.height);	// display image size = camera image size + scaled registered image size
	Mat viewimg = Mat(imgsize, CV_8UC3);	// display image
	viewimg.setTo(Scalar(255,0,0));		// set blue to the margin
	Rect camera_roi = Rect(0,0,framesize.width,framesize.height);	// camera image area in a display image
	Mat camera_img(viewimg, camera_roi);	// camera image display

	// create window
	const string windowNameCam = "Camera Image";
	cv::namedWindow( windowNameCam, CV_WINDOW_AUTOSIZE );

	Point offset_pt;
	offset_pt.x = framesize.width;
	offset_pt.y = 0;
	vector<Point> regimg_roi_pt;
	vector<Mat>::iterator mat_itr;
	for(mat_itr = imglist.begin(); mat_itr != imglist.end(); mat_itr++){
		Size cur_size = mat_itr->size();	// a registered image size

		cur_size.width *= scale;
		cur_size.height *= scale;
		Rect cur_roi(offset_pt.x, offset_pt.y, cur_size.width, cur_size.height);	// an area in a display image
		Mat cur_img(viewimg, cur_roi);
		cv::resize(*mat_itr, cur_img, cur_size);	// registered image is copied to the area in the display image
		regimg_roi_pt.push_back(offset_pt);
		offset_pt.y += cur_size.height;
	}
	Rect regist_roi = Rect(camera_roi.width, 0, imgsize.width - camera_roi.width, camera_roi.height);	// registered image area in a display image

	Mat regist_img(viewimg, regist_roi);	// area of registered images in display image
	Mat bkup_viewimg = regist_img.clone();

	Mat resize_img(frame.rows/2, frame.cols/2, CV_8UC3);	// resized image for faster processing

	// Main Loop
	do {
		vector<KeyPoint>	key_pts;
		Mat	desp_vec;

		// capture an image from a camera
		capture >> frame;
        //cv::flip(frame,frame,1);

		// To improve processing speed, make image smaller
		cv::pyrDown( frame, resize_img, resize_img.size());

		// keypoints detection from a query image
		feature_detector->detect(resize_img, key_pts);
		// descriptor extraction
		descriptor_extractor->compute(resize_img, key_pts, desp_vec);

		// search nearest descriptor in database
		vector<vector<DMatch> > match_idx;
		descriptor_matcher->knnMatch(desp_vec, match_idx, 2);

		// copy camera image to display
		frame.copyTo(camera_img);
		// copy registered images to deisplay
		bkup_viewimg.copyTo(regist_img);

		vector<vector<DMatch> >::iterator dmatch_itr;

		// draw matching points 
		for(dmatch_itr = match_idx.begin(); dmatch_itr != match_idx.end(); dmatch_itr++){
			DMatch d_match = (*dmatch_itr)[0];
			Point src_pt = key_pts[d_match.queryIdx].pt;
			src_pt.x *= 2;
			src_pt.y *= 2;
			drawMatchingPoints(viewimg, 
				src_pt, 
				kpt_db[d_match.imgIdx][d_match.trainIdx].pt, 
				regimg_roi_pt[d_match.imgIdx],
				scale,
				color[d_match.imgIdx]);
		}

		cv::imshow( windowNameCam, viewimg);

	} while( cv::waitKey( 1) != 'q' );	// quit when key 'q' is clicked

	return 0;
}

