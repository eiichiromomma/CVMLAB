// MultiFaceDecoration.cpp : Detect face and create mosaic on it
// OpenCV Demo program for RSJ2011
// E.Momma and T.Minagawa

#include "opencv2/opencv.hpp"

using namespace std;

// create masaic image
// img: input image
// rect: mosaic area
// size: mosaic block size
void createMosaic(cv::Mat& img, cv::Rect rect, int size)
{
	assert(img.channels() == 3);	// Input image must be color
	assert(img.depth()==CV_8U);	// Input image data type must be uchar

	unsigned char* ptr = (unsigned char*)(img.data);	// Data pointer of image
	unsigned char *offset_ptr, *offset_ptr2;

	int x,y,mx,my;
	int r,g,b;

    int w_step = img.step;		// block size of an image row

	int w_r = rect.width % size;
	int h_r = rect.height % size;

	int xb = rect.x + w_r/2;
	int yb = rect.y + h_r/2;
	int xe = xb + rect.width - w_r;
	int ye = yb + rect.height - h_r;

	int area = size * size;

	for(y=yb;y<ye;y+=size){
		for(x=xb;x<xe;x+=size){
			b=0;
			g=0;
			r=0;
			offset_ptr = ptr + y*w_step + 3*x;
			for(my=0;my<size;my++){
				for(mx=0;mx<size;mx++){
					offset_ptr2 = offset_ptr + my*w_step + 3*mx;
					b += *(offset_ptr2);
					g += *(offset_ptr2 +1);
					r += *(offset_ptr2 +2);
				}
			}
			b /= area;
			g /= area;
			r /= area;
			for(my=0;my<size;my++){
				for(mx=0;mx<size;mx++){
					offset_ptr2 = offset_ptr + my*w_step + 3*mx;
					*(offset_ptr2) = b;
					*(offset_ptr2 +1) = g;
					*(offset_ptr2 +2) = r;
				}
			}
		}
	}
}


int main()
{
	int key;
	string windowNameCapture = "Capture";
	cv::VideoCapture	capture( 0 );
	cv::Mat frameImage;

	if( !capture.isOpened() ) {
		// If a camera was not found
		std::cout << "Failed to Open Camera" << std::endl;
		return -1;
	}

	string cascadefile = "haarcascades/haarcascade_frontalface_default.xml";

	// Load face detector
	cv::CascadeClassifier cascade(cascadefile);
	
	capture >> frameImage;

	cv::Mat image(frameImage.rows/2,frameImage.cols/2,CV_8UC3);
	int scale = 2;

	// Create Window
	cv::namedWindow(windowNameCapture, CV_WINDOW_AUTOSIZE);

	// Main Loop
	while(1){
		// capture an image from camera
		capture >> frameImage;

		// To improve processing speed, make image smaller
		cv::pyrDown( frameImage, image, image.size());

		// face detection
		vector<cv::Rect>	detected_faces;
		cascade.detectMultiScale(image, detected_faces);

		// create mosaic on all detected face areas
		vector<cv::Rect>::iterator face_itr;		
		for( face_itr = detected_faces.begin(); face_itr != detected_faces.end(); face_itr++ )
		{
			cv::Rect face_rect = *face_itr;
			face_rect.x *= scale;
			face_rect.y *= scale;
			face_rect.width *= scale;
			face_rect.height *= scale;
			createMosaic(frameImage, face_rect, face_rect.width / 6);	// create mosaic
		}
		// show image on window
		cv::imshow(windowNameCapture, frameImage);

		// exit loop by a key 'q'
		key = cvWaitKey(1);
		if( key == 'q'){
			break;
		}
	}
	return 0;
}

