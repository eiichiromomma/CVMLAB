//�����m�F��letter_recog.cpp�ł̃f��  2008/5/1 Eiichiro Momma

#include "ml.h"
#include <stdio.h>

#include "myCrossVal.h"
#include <list>
#include <algorithm>

/*
The sample demonstrates how to train Random Trees classifier
(or Boosting classifier, or MLP - see main()) using the provided dataset.

We use the sample database letter-recognition.data
from UCI Repository, here is the link:

Newman, D.J. & Hettich, S. & Blake, C.L. & Merz, C.J. (1998).
UCI Repository of machine learning databases
[http://www.ics.uci.edu/~mlearn/MLRepository.html].
Irvine, CA: University of California, Department of Information and Computer Science.

The dataset consists of 20000 feature vectors along with the
responses - capital latin letters A..Z.
The first 16000 (10000 for boosting)) samples are used for training
and the remaining 4000 (10000 for boosting) - to test the classifier.
*/

// This function reads data and responses from the file <filename>
static int
read_num_class_data( const char* filename, int var_count,
                     CvMat** data, CvMat** responses )
{
    const int M = 1024;
    FILE* f = fopen( filename, "rt" );
    CvMemStorage* storage;
    CvSeq* seq;
    char buf[M+2];
    float* el_ptr;
    CvSeqReader reader;
    int i, j;

    if( !f )
        return 0;

    el_ptr = new float[var_count+1];
    storage = cvCreateMemStorage();
    seq = cvCreateSeq( 0, sizeof(*seq), (var_count+1)*sizeof(float), storage );

    for(;;)
    {
        char* ptr;
        if( !fgets( buf, M, f ) || !strchr( buf, ',' ) )
            break;
        el_ptr[0] = buf[0];
        ptr = buf+2;
        for( i = 1; i <= var_count; i++ )
        {
            int n = 0;
            sscanf( ptr, "%f%n", el_ptr + i, &n );
            ptr += n + 1;
        }
        if( i <= var_count )
            break;
        cvSeqPush( seq, el_ptr );
    }
    fclose(f);

    *data = cvCreateMat( seq->total, var_count, CV_32F );
    *responses = cvCreateMat( seq->total, 1, CV_32F );

    cvStartReadSeq( seq, &reader );

    for( i = 0; i < seq->total; i++ )
    {
        const float* sdata = (float*)reader.ptr + 1;
        float* ddata = data[0]->data.fl + var_count*i;
        float* dr = responses[0]->data.fl + i;

        for( j = 0; j < var_count; j++ )
            ddata[j] = sdata[j];
        *dr = sdata[-1];
        CV_NEXT_SEQ_ELEM( seq->elem_size, reader );
    }

    cvReleaseMemStorage( &storage );
    delete el_ptr;
    return 1;
}

void call_classifier(CrossVal* c)
{
  c->classifier();
}

int rt_classifier_cv( char* data_filename )
{
    const int class_count = 26;
    CvMat* data = 0;
    CvMat* responses = 0;

    int ok = read_num_class_data( data_filename, 16, &data, &responses );
    int nsamples_all = 0;
    if( !ok )
    {
        printf( "Could not read the database %s\n", data_filename );
        return -1;
    }
    nsamples_all = data->rows;
    for (int i=0; i< responses->rows; i++){
      responses->data.fl[i] = responses->data.fl[i] - 'A';
    }
    //�����܂ŋ���
    //�P�i
    /*
    CvTermCriteria ctc = cvTermCriteria(CV_TERMCRIT_ITER,30,0.01);
    CvRTrees* rt = new CvRTrees();
    CrossValRTrees* cvrt = new CrossValRTrees(rt, data, responses, ctc,
      CvRTParams(15, 2, 0, false, data->cols, 0, false, 8, ctc.max_iter, ctc.epsilon, ctc.type),2000);
    cvrt->classifier();
    */
    //�p�����[�^�����s���낷��ꍇ
    CvTermCriteria ctc = cvTermCriteria(CV_TERMCRIT_ITER,30,0.01);
    std::list<CrossValRTrees*> rtlist;
    CvRTrees* rt = new CvRTrees();
    rtlist.push_front(new CrossValRTrees(rt, data, responses, ctc,
      CvRTParams(15, 2, 0, false, data->cols, 0, false, 8, ctc.max_iter, ctc.epsilon, ctc.type),2000));
    rtlist.push_back(new CrossValRTrees(rt, data, responses, ctc,
      CvRTParams( 15, 3, 0, false, data->cols, 0, false,8, ctc.max_iter, ctc.epsilon, ctc.type),2000));
    std::for_each(rtlist.begin(), rtlist.end(), call_classifier);

    return 0;
}

int svm_classifier_cv( char* data_filename )
{
    const int class_count = 26;
    CvMat* data = 0;
    CvMat* responses = 0;

    int ok = read_num_class_data( data_filename, 16, &data, &responses );
    int nsamples_all = 0;
    if( !ok )
    {
        printf( "Could not read the database %s\n", data_filename );
        return -1;
    }
    nsamples_all = data->rows;
    for (int i=0; i< responses->rows; i++){
      responses->data.fl[i] = responses->data.fl[i] - 'A';
    }
    //�����܂ŋ���
    //�P�i
/*
    CvTermCriteria ctc = cvTermCriteria(CV_TERMCRIT_ITER,100,0.001);
    CvSVM* s = new CvSVM();
    CrossValSvm* cvsvm = new CrossValSvm(s,data, responses, 
      CvSVMParams(CvSVM::NU_SVC, CvSVM::RBF, 0.0, 0.1, 0.0, 0.0, 0.2, 0.0,NULL,ctc),4000);
    cvsvm->classifier();
*/

    //�p�����[�^�����s���낷��ꍇ
    CvTermCriteria ctc = cvTermCriteria(CV_TERMCRIT_ITER,300,0.001);
    std::list<CrossValSvm*> slist;
    CvSVM* s = new CvSVM();
    slist.push_front(new CrossValSvm(s,data, responses, CvSVMParams(CvSVM::NU_SVC, CvSVM::RBF, 0.0, 0.1, 0.0, 0.0, 0.2, 0.0,NULL,ctc),2000));
    slist.push_back(new CrossValSvm(s,data, responses, CvSVMParams(CvSVM::C_SVC, CvSVM::RBF, 0.0, 3, 0.0, 1000, 0.0, 0.0,NULL,ctc),2000));
    std::for_each(slist.begin(), slist.end(), call_classifier);

    return 0;
}

int mlp_classifier_cv( char* data_filename )
{
    const int class_count = 26;
    CvMat* data = 0;
    CvMat* responses = 0;

    int ok = read_num_class_data( data_filename, 16, &data, &responses );
    int nsamples_all = 0;
    if( !ok )
    {
        printf( "Could not read the database %s\n", data_filename );
        return -1;
    }
    nsamples_all = data->rows;
    for (int i=0; i< responses->rows; i++){
      responses->data.fl[i] = responses->data.fl[i] - 'A';
    }

    //�����܂ŋ���
    //�P�i
/*
    CvTermCriteria ctc = cvTermCriteria(CV_TERMCRIT_ITER,300,0.1);
    CvANN_MLP* m = new CvANN_MLP();
    int layer_sz[] = { data->cols, 50, class_count };
    CvMat layer_sizes = cvMat( 1, (int)(sizeof(layer_sz)/sizeof(layer_sz[0])), CV_32S, layer_sz );
    CvANN_MLP_TrainParams tr_params = CvANN_MLP_TrainParams(ctc,CvANN_MLP_TrainParams::RPROP,0.3);
    CrossValMLP* cvmlp = new CrossValMLP(m,data,responses,&layer_sizes,tr_params,CvANN_MLP::SIGMOID_SYM,4000);
    cvmlp->classifier();
*/

    //�p�����[�^�����s���낷��ꍇ
    CvANN_MLP* m = new CvANN_MLP();
    CvTermCriteria ctc = cvTermCriteria(CV_TERMCRIT_ITER,300,0.1);
    std::list<CrossValMLP*> mlplist;
    int layer_sz[] = { data->cols, 50, class_count };
    CvMat layer_sizes = cvMat( 1, (int)(sizeof(layer_sz)/sizeof(layer_sz[0])), CV_32S, layer_sz );
    CvANN_MLP_TrainParams tr_params = CvANN_MLP_TrainParams(ctc,CvANN_MLP_TrainParams::RPROP,0.3);
    mlplist.push_front(new CrossValMLP(m,data,responses,&layer_sizes,tr_params,CvANN_MLP::SIGMOID_SYM,4000));
    
    int layer_sz2[] = { data->cols, 25, 25, class_count };
    CvMat layer_sizes2 = cvMat( 1, (int)(sizeof(layer_sz2)/sizeof(layer_sz2[0])), CV_32S, layer_sz2 );
    mlplist.push_back(new CrossValMLP(m,data,responses,&layer_sizes2,tr_params,CvANN_MLP::SIGMOID_SYM,4000));
    std::for_each(mlplist.begin(),mlplist.end(), call_classifier);

    return 0;
}

int main( int argc, char *argv[] )
{
    char* filename_to_save = 0;
    char* filename_to_load = 0;
    char default_data_filename[] = "./letter-recognition.data";
    char* data_filename = default_data_filename;
    int method = 0;

    int i;
    for( i = 1; i < argc; i++ )
    {
        if( strcmp(argv[i],"-data") == 0 ) // flag "-data letter_recognition.xml"
        {
            i++;
            data_filename = argv[i];
        }
        else if( strcmp(argv[i],"-mlp") == 0 )
        {
            method = 1;
        }
        else if( strcmp(argv[i],"-svm") == 0 )
        {
            method = 2;
        }
        else
            break;
    }

    if( i < argc ||
        (method == 0 ?
        rt_classifier_cv( data_filename ):
        method == 1 ?
          mlp_classifier_cv(data_filename):
        method == 2 ?
          svm_classifier_cv(data_filename):
        -1) < 0)
    {
        printf("This is letter recognition sample.\n"
                "The usage: letter_recog [-data <path to letter-recognition.data>] \\\n"
                "  [-svm|-mlp] # to use svm/mlp classifier instead of default Random Trees\n" );
    }
    return 0;
}
