//�����m�F 2008/5/1 Eiichiro Momma
#pragma once
#include <cv.h>
#include <highgui.h>
#include <ml.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

enum{
  ML_DEBUG=1
};

class CrossVal{
public:
  virtual bool train(void){return 0;}
  virtual float predict(CvMat* ){return 0;}
  virtual int get_val(void){return 0;}
  virtual void print_val(void){;}
  virtual void ml_clear(void){;}
  virtual void clear(void) {;}
  virtual void print(void)
  {
    printf("Number of Contents:");
    for (int i=0; i<nCategory_; i++){
      printf("%ld,",get_hist(i));
    }
    printf("\n");
    for (int r=0; r<nCategory_; r++){
      for (int c=0; c<nCategory_; c++){
        printf("%4d ",(int)cvmGet(res_table_,r,c));
      }
      printf("\n");
    }
    printf("\n");
  }
  void release_sample_idx(void){cvReleaseMat(&sample_idx_);}
  void set_var_type(CvMat* val){var_type_ = val;}
  CvMat* var_type(void){return var_type_;}
  void set_data(CvMat* val){data_ = val;}
  CvMat* data(void){return data_;}
  void set_sample_idx(CvMat* val){sample_idx_ = val;}
  CvMat* sample_idx(void){return sample_idx_;}
  void set_responses(CvMat* val){responses_ = val;}
  CvMat* responses(void){return responses_;}
  int ntest_samples(void){return ntest_samples_;}
  CvTermCriteria term_crit(void){return term_crit_;}
  int classifier(void);
  CrossVal(CvMat* _data, CvMat* _responses, CvTermCriteria _term_crit, int _ntest_samples)
  {
    data_ = _data;
    responses_ = _responses;
    term_crit_ = _term_crit;
    ntest_samples_ = _ntest_samples;
    var_type_ = NULL;
    sample_idx_ = NULL;
    init_hist();
  }
  long get_hist(int key){
    return (long)cvmGet(data_hist_,key,0);
  }
  int get_nCategory(void){
    return nCategory_;
  }

private:
  CvMat* data_;
  CvMat* responses_;
  CvMat* sample_idx_;
  CvMat* var_type_;
  CvMat* res_table_;
  CvMat* data_hist_;
  CvTermCriteria term_crit_;
  int ntest_samples_;
  int nCategory_;
  void init_hist(void)
  {
    double max=-1;
    int i;
    for (i=0; i<responses_->rows; i++){
      if (max < responses_->data.fl[i]){
        max = responses_->data.fl[i];
      }
    }
    nCategory_ = (int)max + 1;
    data_hist_ = cvCreateMat(nCategory_,1,CV_32FC1);
    res_table_ = cvCreateMat(nCategory_,nCategory_,CV_32FC1);
    cvSet(data_hist_,cvScalar(0));
    cvSet(res_table_,cvScalar(0));
    double val=0;
    double tru_val;
    for (i=0; i< responses_->rows; i++){
      tru_val = responses_->data.fl[i];
      val=cvmGet(data_hist_,(int)tru_val,0);
      cvmSet(data_hist_,(int)tru_val,0,1+val);
    }
  }  
};

class CrossValMLP:public CrossVal{
public:
  CvANN_MLP* mlp;
  void ml_clear(){mlp->clear();}
  int get_val(){return mlp->get_layer_count();}
  void print_val(){
    printf( "%d Layers,", get_val() );
  }
  bool train(){
    mlp->create(layer_sizes_, active_func_, alpha_, beta_);
    return (mlp->train(data(), new_responses_, 0, sample_idx(), tr_params_) > 0 ) ? true: false ;
  }

  void print(){
    printf("Layer = {");
    for (int i=0; i < layer_sizes_->cols ; i++){
      printf("%d, ",layer_sizes_->data.i[i]);
    }
    printf("}\n");
    CrossVal::print();
  }

  CrossValMLP(CvANN_MLP* _mlp, CvMat* _data, CvMat* _responses, 
    CvMat* _layer_sizes, CvANN_MLP_TrainParams _tr_params, int _active_func,int _ntest_samples,
    double _param1=1.0,double _param2=1.0 ):CrossVal(_data, _responses, _tr_params.term_crit, _ntest_samples)
  {
    mlp = _mlp;
    layer_sizes_ = _layer_sizes;
    active_func_ = _active_func;
    alpha_ = _param1;
    beta_ = _param2;
    tr_params_ = _tr_params;
    UnRoll();
  }
private:
  double alpha_;
  double beta_;
  CvMat* layer_sizes_;
  int active_func_; // IDENTITY, SIGMOID_SYM, GAUSSIAN
  CvMat* new_responses_;
  CvANN_MLP_TrainParams tr_params_;
  void UnRoll(){
    new_responses_ = cvCreateMat(data()->rows, get_nCategory(), CV_32F );
    for(int i = 0; i < data()->rows; i++ )
    {
      //cls_label(����)
      int cls_label = cvRound(responses()->data.fl[i]);
      //new_responses��1�T���v�����̃x�N�g���̃|�C���^�̎擾
      float* bit_vec = (float*)(new_responses_->data.ptr + i*new_responses_->step);
      //�S����0(float)�𖄍���
      for(int j = 0; j < get_nCategory(); j++ )
          bit_vec[j] = 0.f;
      //cls_label(����)�ɂ���1(float)�𗧂Ă�
      bit_vec[cls_label] = 1.f;
    }
  }
  float predict(CvMat* sample){
    CvMat* mlp_response = cvCreateMat( 1, get_nCategory(), CV_32F );
    CvPoint max_loc = {0,0};
    mlp->predict( sample, mlp_response );
    cvMinMaxLoc( mlp_response, 0, 0, 0, &max_loc, 0 );
    int best_class = max_loc.x;
    cvReleaseMat(&mlp_response);
    return (float)best_class;
  }
};

class CrossValSvm:public CrossVal{
public:
  void ml_clear(){svm_->clear();}
  float predict(CvMat* sample){return svm_->predict(sample);}
  int get_val(){return svm_->get_support_vector_count();}
  void print_val(){
    printf( "%d SupportVectors,", get_val() );
  }

  bool train(){
     return svm_->train(data(), responses(), 0, sample_idx(), svm_params_);
  }
  CrossValSvm(CvSVM* _svm, CvMat* _data, CvMat* _responses, CvSVMParams _svm_params,
    int _ntest_samples):CrossVal(_data, _responses, _svm_params.term_crit , _ntest_samples)
  {
    svm_ = _svm;
    svm_params_ = _svm_params;
  }
private:
  CvSVM* svm_;
  CvSVMParams svm_params_;
public:
  void print(void)
  {
    char st[20];
    char kt[20];
    switch(svm_params_.svm_type){
      case (CvSVM::C_SVC):
        strcpy(st,"C_SVC");
        break;
      case (CvSVM::NU_SVC):
        strcpy(st,"NU_SVC");
        break;
      case (CvSVM::ONE_CLASS):
        strcpy(st,"ONE_CLASS");
        break;
      case (CvSVM::EPS_SVR):
        strcpy(st,"EPS_SVR");
        break;
      case (CvSVM::NU_SVR):
        strcpy(st,"NU_SVR");
        break;
    }
    switch(svm_params_.kernel_type){
      case (CvSVM::LINEAR):
        strcpy(kt,"LINEAR");
        break;
      case (CvSVM::POLY):
        strcpy(kt,"POLY");
        break;
      case (CvSVM::RBF):
        strcpy(kt,"RBF");
        break;
      case (CvSVM::SIGMOID):
        strcpy(kt,"SIGMOID");
        break;
    }
    printf("=================Supoprt Vector Machine=======================\n");
    printf("%s,%s,",st,kt);
    printf("%d/%dCV,",ntest_samples(),data()->rows);
    printf("max_iter=%d,epsilon=%lf,",term_crit().max_iter, term_crit().epsilon);
    if(fabs(svm_params_.degree) >= DBL_EPSILON){
      printf("degree=%lf,",svm_params_.degree);
    }
    if(fabs(svm_params_.gamma) >= DBL_EPSILON){
      printf("gamma=%lf,", svm_params_.gamma);
    }
    if(fabs(svm_params_.coef0) >= DBL_EPSILON){
      printf("coef0=%lf,",svm_params_.coef0);
    }
    if(fabs(svm_params_.C) >= DBL_EPSILON){
      printf("C=%lf,",svm_params_.C);
    }
    if(fabs(svm_params_.nu) >= DBL_EPSILON){
      printf("nu=%lf,",svm_params_.nu);
    }
    if(fabs(svm_params_.p) >= DBL_EPSILON){
      printf("p=%lf,",svm_params_.p);
    }
    printf("\n");
    CrossVal::print();
  }

};

class CrossValRTrees:public CrossVal{
public:
  void ml_clear(void){
    forest_->clear();
  }
  float predict(CvMat* sample){return forest_->predict(sample);}
  int get_val(void){return forest_->get_tree_count();}
  void print_val(void){
    printf("Trees :%d\n",get_val());
  }
  bool train(){
    if(var_type() == NULL){
      set_var_type(cvCreateMat( data()->cols + 1, 1, CV_8U ));
      cvSet( var_type(), cvScalarAll(CV_VAR_ORDERED) );
      //�Ō��1��(�o�͂ł�����responses�̌`��)�����I�f�[�^�Ɏw��
      cvSetReal1D( var_type(), data()->cols, CV_VAR_CATEGORICAL );
    }
    return forest_->train(data(),CV_ROW_SAMPLE, responses(), 0, sample_idx(), var_type(),0,rt_params_);
  }
  CrossValRTrees(CvRTrees* _forest, CvMat* _data, CvMat* _responses, CvTermCriteria _term_crit, CvRTParams _rt_params,
    int _ntest_samples):CrossVal(_data, _responses, _term_crit, _ntest_samples)
  {
    forest_=_forest;
    rt_params_ = _rt_params;
  }
private:
  CvRTrees* forest_;
  CvRTParams rt_params_;
public:
  void print(void)
  {
    printf("=======================Random Trees==========================\n");
    printf("%d/%dCV,",ntest_samples(),data()->rows);
    printf("max_iter=%d,epsilon=%lf,",term_crit().max_iter, term_crit().epsilon);
    if(rt_params_.max_depth!=0){
      printf("max_depth=%d,",rt_params_.max_depth);
    }
    if(rt_params_.min_sample_count!=0){
      printf("min_sample_count=%d,",rt_params_.min_sample_count);
    }
    if(fabs(rt_params_.regression_accuracy) >= FLT_EPSILON){
      printf("regression_accuracy=%f,",rt_params_.regression_accuracy);
    }
    if (rt_params_.use_surrogates){
      printf("use_surrogates:True,");
    }
    if(rt_params_.max_categories!=0){
      printf("max_categories=%d,",rt_params_.max_categories);
    }
    if (rt_params_.calc_var_importance){
      printf("calc_var_importance:True,");
    }
    if(rt_params_.nactive_vars!=0){
      printf("nactive_vars=%d,",rt_params_.nactive_vars);
    }
    if(rt_params_.term_crit.max_iter!=0){
      printf("max_tree_count=%d,",rt_params_.term_crit.max_iter);
    }
    if(fabs(rt_params_.term_crit.epsilon) >= FLT_EPSILON){
      printf("forest_accuracy=%f,",rt_params_.term_crit.epsilon);
    }
    if(rt_params_.term_crit.type!=0){
      printf("termcrit_type=%d,",rt_params_.term_crit.type);
    }

    printf("\n");
    CrossVal::print();
  }

};

