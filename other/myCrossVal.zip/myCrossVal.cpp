//�����m�F 2008/5/1 Eiichiro Momma
#include "myCrossVal.h"


int CrossVal::classifier()
{
  int nsamples_all = 0;
  int i = 0;
  double val;
  nsamples_all = data()->rows;

  //�����m�F
  CvRNG rng = cvRNG(clock());
  CvMat* cross_val_idx;
  cross_val_idx = cvCreateMat(1,nsamples_all,CV_32S);
  for (i=0; i<nsamples_all; i++){
    cross_val_idx->data.i[i] = i;
  }
  cvRandShuffle(cross_val_idx,&rng);
  
  // 2. create this->sample_idx()
  set_sample_idx( cvCreateMat( 1, nsamples_all, CV_8UC1 ));
  int ncross_val_time = (int)ceil((double)nsamples_all/ntest_samples());
  double* test_hr = new double[ncross_val_time];
  double* train_hr = new double[ncross_val_time];
  memset(test_hr,0,sizeof(double)*ncross_val_time);
  memset(train_hr,0,sizeof(double)*ncross_val_time);
  for (int j = 0; j < ncross_val_time; j++){
    int cross_val_start = j*ntest_samples();
    int cross_val_end = (j == ncross_val_time-1) ? nsamples_all: (j+1)*ntest_samples();
    cvSet(sample_idx(),cvRealScalar(1));
    for (i=0; i<nsamples_all; i++){
      if (cross_val_idx->data.i[i] >= cross_val_start && cross_val_idx->data.i[i] < cross_val_end){
        cvSet1D(sample_idx(),i,cvRealScalar(0));
      }
    }
    if (ML_DEBUG){
      printf( "Training: classifier %d\n",j+1);
    }
    train();
    // compute prediction error on train and test data
    if (get_val() == 0){
      printf("Train Error\n");
      return -1;
    }
    if(ML_DEBUG){
      printf( "Cross Validation: classifier %d\n",j+1);
    }
    for( i = 0; i < nsamples_all; i++ )
    {
      double r;
      CvMat sample;
      cvGetRow( data(), &sample, i );
      r = predict( &sample );
      if( cvGet1D(sample_idx(),i).val[0] == 0 ){
        val = cvmGet(res_table_,(int)responses_->data.fl[i],(int)r);
        cvmSet(res_table_,(int)responses_->data.fl[i],(int)r,val+1);
      }
      r = fabs((double)r - responses()->data.fl[i]) <= FLT_EPSILON ? 1 : 0;
      if( cvGet1D(sample_idx(),i).val[0] == 1 ){
        train_hr[j] += r;
      }else{
        test_hr[j] += r;
      }
    }
    test_hr[j] /= (double)(cross_val_end-cross_val_start);
    train_hr[j] /= (double)(nsamples_all - (cross_val_end-cross_val_start));
    if(ML_DEBUG == 1){
      printf("test%d/%d: ",j+1,ncross_val_time);
      print_val();
      printf( "Recognition Rate: train= %.1lf%%, test= %.1lf%%\n",
              train_hr[j]*100., test_hr[j]*100. );
    }
    ml_clear();
  }
  double total_test_hr=0.0;
  double total_train_hr=0.0;
  for(i=0; i< ncross_val_time; i++){
    total_test_hr+= test_hr[i];
    total_train_hr+= train_hr[i];
  }
  total_test_hr/=ncross_val_time;
  total_train_hr/=ncross_val_time;
  print();
  clear();
  printf( "Total Recognition Rate: train = %.1lf%%, test = %.1lf%%\n", total_train_hr*100, total_test_hr*100);
  release_sample_idx();
  return 0;
}

